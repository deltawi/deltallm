import asyncio
import json
import subprocess
import types
from uuid import uuid4
from redis.asyncio import Redis
from src.db.repositories import KeyRecord
from src.models.errors import AuthenticationError
from src.services.key_service import KeyService
from tests.performance.key_auth_revocation_profile import before_service

class Repo:
    def __init__(self, record=None):
        self.record, self.calls = record, 0
    async def get_by_token(self, token):
        self.calls += 1
        return self.record

async def deny(call):
    try:
        await call
    except AuthenticationError:
        return
    raise AssertionError('Deleted key was authorized')

async def main():
    redis = Redis.from_url('redis://127.0.0.1:56429/4', decode_responses=True)
    tokens = []
    try:
        token = uuid4().hex
        tokens.append(token)
        repo = Repo(KeyRecord(token=token, owner_account_id='owner'))
        new = KeyService(repo, redis, auth_cache_ttl_seconds=30)
        await new.get_auth_by_token_hash(token)
        old5 = before_service('4facbbea0730ed64058b954b1dc47979f2c940f7')(repo, redis, auth_cache_ttl_seconds=1)
        assert (await old5.get_auth_by_token_hash(token)).owner_account_id == 'owner'
        assert repo.calls == 1
        repo.record = None
        await old5.mark_key_revoked_by_hash(token)
        await deny(new.get_auth_by_token_hash(token))
        await asyncio.sleep(3.1)
        assert await redis.get('key:v5:' + token) is None
        assert await redis.get('key:v7:' + token) is not None
        await deny(new.get_auth_by_token_hash(token))
        print('PASS: the actual main v5 reader accepts the paired legacy snapshot; its shorter revocation cannot restore v7 auth after expiry.')
        module = types.ModuleType('src.services._fixed_review_v6_key_service')
        module.__package__ = 'src.services'
        source = subprocess.check_output(['git', 'show', '10a34f1e229f5f41ea16e6e2eaee544c984f1da1:src/services/key_service.py'], text=True)
        exec(compile(source, '<original-v6-key-service>', 'exec'), module.__dict__)
        old6 = module.KeyService(repo, redis, salt='qualification', auth_cache_ttl_seconds=300)
        raw = 'sk-' + uuid4().hex
        token = old6.hash_key(raw)
        tokens.append(token)
        repo.record = KeyRecord(token=token)
        await old6.validate_key(raw)
        assert await redis.ttl('key:v6:' + token) > 61
        repo.record = None
        await KeyService(repo, redis, auth_cache_ttl_seconds=1).mark_key_revoked_by_hash(token)
        assert await redis.get('key:v6:' + token) is None
        await deny(old6.validate_key(raw))
        print('PASS: new revocation clears the actual v6 reader\'s 300-second snapshot, and that reader denies the deleted key.')
    finally:
        for token in tokens:
            await redis.delete(*(f'key:v{v}:{token}' for v in (4,5,6,7)))
        await redis.aclose()

asyncio.run(main())
