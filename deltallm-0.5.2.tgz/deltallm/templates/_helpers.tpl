{{- define "deltallm.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "deltallm.validateRouterStateSchemaCutover" -}}
{{- $installedRouterSchema := "" -}}
{{- if .Release.IsUpgrade -}}
{{- $configName := printf "%s-config" (include "deltallm.fullname" .) -}}
{{- $installedConfig := lookup "v1" "ConfigMap" .Release.Namespace $configName | default dict -}}
{{- $annotations := dig "metadata" "annotations" (dict) $installedConfig -}}
{{- $installedRouterSchema = get $annotations "deltallm.ai/router-state-schema" | default "" -}}
{{- end -}}
{{- if and .Release.IsUpgrade .Values.routerStateSchemaCutover.enabled (ne $installedRouterSchema "v1") -}}
{{- if not .Values.routerStateSchemaCutover.acknowledged -}}
{{- fail "router Redis v1 schema cutover requires draining and stopping every old API and batch-worker pod, then setting routerStateSchemaCutover.acknowledged=true" -}}
{{- end -}}
{{- if ne .Values.strategy.type "Recreate" -}}
{{- fail "router Redis v1 schema cutover requires strategy.type=Recreate; RollingUpdate would split admission and cooldown ownership" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "deltallm.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "deltallm.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "deltallm.labels" -}}
helm.sh/chart: {{ include "deltallm.chart" . }}
{{ include "deltallm.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "deltallm.selectorLabels" -}}
app.kubernetes.io/name: {{ include "deltallm.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "deltallm.batchWorkerName" -}}
{{- $base := include "deltallm.name" . | trunc 50 | trimSuffix "-" -}}
{{- printf "%s-batch-worker" $base -}}
{{- end -}}

{{- define "deltallm.batchWorkerFullname" -}}
{{- $base := include "deltallm.fullname" . | trunc 50 | trimSuffix "-" -}}
{{- printf "%s-batch-worker" $base -}}
{{- end -}}

{{- define "deltallm.batchWorkerSelectorLabels" -}}
app.kubernetes.io/name: {{ include "deltallm.batchWorkerName" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: batch-worker
{{- end -}}

{{- define "deltallm.batchWorkerLabels" -}}
helm.sh/chart: {{ include "deltallm.chart" . }}
{{ include "deltallm.batchWorkerSelectorLabels" . }}
app.kubernetes.io/part-of: {{ include "deltallm.name" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "deltallm.accountingWorkerName" -}}
{{- $base := include "deltallm.name" . | trunc 45 | trimSuffix "-" -}}
{{- printf "%s-accounting-worker" $base -}}
{{- end -}}

{{- define "deltallm.accountingWorkerFullname" -}}
{{- $base := include "deltallm.fullname" . | trunc 45 | trimSuffix "-" -}}
{{- printf "%s-accounting-worker" $base -}}
{{- end -}}

{{- define "deltallm.accountingWorkerSelectorLabels" -}}
app.kubernetes.io/name: {{ include "deltallm.accountingWorkerName" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: accounting-worker
{{- end -}}

{{- define "deltallm.accountingWorkerLabels" -}}
helm.sh/chart: {{ include "deltallm.chart" . }}
{{ include "deltallm.accountingWorkerSelectorLabels" . }}
app.kubernetes.io/part-of: {{ include "deltallm.name" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "deltallm.accountingRequestFullname" -}}
{{- printf "%s-accounting-request" (include "deltallm.fullname" . | trunc 44 | trimSuffix "-") -}}
{{- end -}}

{{- define "deltallm.accountingRequestSelectorLabels" -}}
app.kubernetes.io/name: {{ printf "%s-accounting-request" (include "deltallm.name" . | trunc 44 | trimSuffix "-") }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: accounting-request
{{- end -}}

{{- define "deltallm.accountingRequestLabels" -}}
helm.sh/chart: {{ include "deltallm.chart" . }}
{{ include "deltallm.accountingRequestSelectorLabels" . }}
app.kubernetes.io/part-of: {{ include "deltallm.name" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "deltallm.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "deltallm.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "deltallm.appSecretName" -}}
{{- if .Values.secret.existingSecret -}}
{{- .Values.secret.existingSecret -}}
{{- else -}}
{{- printf "%s-app" (include "deltallm.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "deltallm.s3SecretName" -}}
{{- if .Values.s3.existingSecret.name -}}
{{- .Values.s3.existingSecret.name -}}
{{- else -}}
{{- printf "%s-s3" (include "deltallm.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "deltallm.postgresqlHost" -}}
{{- printf "%s-postgresql" (include "deltallm.fullname" .) -}}
{{- end -}}

{{- define "deltallm.redisHost" -}}
{{- printf "%s-redis-master" (include "deltallm.fullname" .) -}}
{{- end -}}

{{- define "deltallm.bundledDatabaseUrl" -}}
{{- $username := required "postgresql.auth.username is required when postgresql.enabled=true and runtime.database.url is not set" .Values.postgresql.auth.username -}}
{{- $password := required "postgresql.auth.password is required when postgresql.enabled=true and runtime.database.url is not set" .Values.postgresql.auth.password -}}
{{- $database := required "postgresql.auth.database is required when postgresql.enabled=true and runtime.database.url is not set" .Values.postgresql.auth.database -}}
{{- printf "postgresql://%s:%s@%s:5432/%s" ($username | urlquery) ($password | urlquery) (include "deltallm.postgresqlHost" .) $database -}}
{{- end -}}

{{- define "deltallm.bundledRedisUrl" -}}
{{- if .Values.redis.auth.enabled -}}
{{- $password := required "redis.auth.password is required when redis.enabled=true and redis.auth.enabled=true unless runtime.redis.existingSecret.name or runtime.redis.url is set" .Values.redis.auth.password -}}
{{- printf "redis://:%s@%s:6379/0" ($password | urlquery) (include "deltallm.redisHost" .) -}}
{{- else -}}
{{- printf "redis://%s:6379/0" (include "deltallm.redisHost" .) -}}
{{- end -}}
{{- end -}}

{{- define "deltallm.image" -}}
{{- if .Values.image.digest -}}
{{- printf "%s@%s" .Values.image.repository .Values.image.digest -}}
{{- else -}}
{{- printf "%s:%s" .Values.image.repository (default .Chart.AppVersion .Values.image.tag) -}}
{{- end -}}
{{- end -}}

{{/*
Chart config: files/config-defaults.yaml under .Values.config, values winning.
Every role's ConfigMap renders these settings explicitly.
*/}}
{{- define "deltallm.chartConfig" -}}
{{- $defaults := .Files.Get "files/config-defaults.yaml" | fromYaml -}}
{{- toYaml (mergeOverwrite $defaults (deepCopy .Values.config)) -}}
{{- end -}}
